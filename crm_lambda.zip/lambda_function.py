import json
import boto3
import random
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('CustomerTable')

# Read index.html content with error handling
try:
    with open('index.html', 'r') as file:
        HTML_CONTENT = file.read()
    print("Successfully loaded index.html")
except Exception as e:
    HTML_CONTENT = "<h1>Error: Could not load index.html</h1>"
    print(f"Failed to load index.html: {str(e)}")

def populate_customers():
    customer_names = [
        "John Doe", "Jane Smith", "Michael Brown", "Emily Davis", "David Wilson", "Sarah Johnson", "Chris Lee", "Anna Taylor",
        "Robert Clark", "Lisa White", "James Miller", "Kelly Green", "Thomas Anderson", "Megan Hall", "Brian Adams"
    ]
    companies = ["TechCorp", "GrowEasy", "BlueSky", "NextGen", "InnovateX"]
    statuses = ["Active", "Inactive"]

    items_added = 0
    for i in range(1, 16):  # Add 15 sample customers
        customer_id = f"C{i:03d}"
        name = random.choice(customer_names)
        email = f"{name.lower().replace(' ', '.')}@example.com"
        phone = f"555-{random.randint(100, 999)}-{random.randint(1000, 9999)}"
        company = random.choice(companies)
        status = random.choice(statuses)

        customer = {
            'customerID': customer_id,
            'name': name,
            'email': email,
            'phone': phone,
            'company': company,
            'status': status
        }
        print(f"Attempting to add customer {customer_id}: {customer}")

        try:
            table.put_item(Item=customer)
            items_added += 1
            print(f"Successfully added customer {customer_id}")
        except Exception as e:
            print(f"Failed to add customer {customer_id}: {str(e)}")
            return {
                'statusCode': 500,
                'headers': {
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': f"Failed to add customer {customer_id}: {str(e)}"})
            }

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({'message': f"Successfully added {items_added} customers to DynamoDB"})
    }

def lambda_handler(event, context):
    try:
        http_method = event['httpMethod']
        path = event.get('path', '/')
        print("Path received:", path)

        # Handle the stage prefix (e.g., /dev)
        if path.startswith('/dev'):
            path = path.replace('/dev', '')

        # Serve the frontend (index.html) for the root path
        if (path == '' or path == '/') and http_method == 'GET':
            print("Serving index.html")
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'text/html',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': HTML_CONTENT
            }

        # Populate the database
        if path == '/populate' and http_method == 'GET':
            print("Calling populate_customers")
            return populate_customers()

        # Add customer
        if path == '/add-customer' and http_method == 'POST':
            body = json.loads(event['body'])
            customer = {
                'customerID': body['customerID'],
                'name': body['name'],
                'email': body['email'],
                'phone': body['phone'],
                'company': body['company'],
                'status': body['status']
            }
            try:
                table.put_item(Item=customer)
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
                        'Access-Control-Allow-Headers': 'Content-Type'
                    },
                    'body': json.dumps({'message': 'Customer added successfully', 'customer': customer})
                }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # Get single customer
        if path == '/get-customer' and http_method == 'GET':
            customer_id = event['queryStringParameters']['customerID']
            try:
                response = table.get_item(Key={'customerID': customer_id})
                customer = response.get('Item')
                if customer:
                    return {
                        'statusCode': 200,
                        'headers': {
                            'Access-Control-Allow-Origin': '*'
                        },
                        'body': json.dumps(customer)
                    }
                else:
                    return {
                        'statusCode': 404,
                        'headers': {
                            'Access-Control-Allow-Origin': '*'
                        },
                        'body': json.dumps({'message': 'Customer not found'})
                    }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # Get all customers
        if path == '/get-all-customers' and http_method == 'GET':
            try:
                response = table.scan()
                customers = response.get('Items', [])
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'customers': customers})
                }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # Update customer
        if path == '/update-customer' and http_method == 'PUT':
            body = json.loads(event['body'])
            customer_id = body['customerID']
            try:
                table.update_item(
                    Key={'customerID': customer_id},
                    UpdateExpression="set #n=:n, email=:e, phone=:p, company=:c, #s=:s",
                    ExpressionAttributeNames={'#n': 'name', '#s': 'status'},
                    ExpressionAttributeValues={
                        ':n': body['name'],
                        ':e': body['email'],
                        ':p': body['phone'],
                        ':c': body['company'],
                        ':s': body['status']
                    }
                )
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'message': 'Customer updated successfully'})
                }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # Delete customer
        if path == '/delete-customer' and http_method == 'DELETE':
            customer_id = event['queryStringParameters']['customerID']
            try:
                table.delete_item(Key={'customerID': customer_id})
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'message': 'Customer deleted successfully'})
                }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # If no matching route is found
        print(f"Unsupported path or method: {path}, {http_method}")
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'message': 'Unsupported HTTP method or path'})
        }

    except Exception as e:
        print(f"Unhandled error in lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': f"Internal server error: {str(e)}"})
        }